package com.example.myapplication

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var latitudeInput: EditText
    private lateinit var longitudeInput: EditText
    private val CAMERA_REQUEST_CODE = 111
    private var photoBitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnSettings = findViewById<Button>(R.id.btnSettings)
        val btnMap = findViewById<Button>(R.id.btnMap)
        val btnCamera = findViewById<Button>(R.id.btnCamera)
        imageView = findViewById(R.id.imageView)
        latitudeInput = findViewById(R.id.latitudeInput)
        longitudeInput = findViewById(R.id.longitudeInput)

        // Przywracanie zdjecia po rotacji
        if (savedInstanceState != null) {
            photoBitmap = savedInstanceState.getParcelable("photoBitmap")
            imageView.setImageBitmap(photoBitmap)
        }

        // Ustawienia wyświetlacza
        btnSettings.setOnClickListener {
            val intent = Intent(Settings.ACTION_DISPLAY_SETTINGS)
            startActivity(intent)
        }

        // Mapa google z współrzędnymi
        btnMap.setOnClickListener {
            val latText = latitudeInput.text.toString().trim()
            val lonText = longitudeInput.text.toString().trim()

            if (latText.isEmpty() || lonText.isEmpty()) {
                Toast.makeText(this, "Podaj obie współrzędne!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val latitude = latText.toDoubleOrNull()
            val longitude = lonText.toDoubleOrNull()

            if (latitude == null || longitude == null) {
                Toast.makeText(this, "Nieprawidłowy format liczby!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Sprawdzanie zakresów goegraficznych
            if (latitude !in -90.0..90.0) {
                Toast.makeText(this, "Szerokość geograficzna musi być w zakresie -90 do 90!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (longitude !in -180.0..180.0) {
                Toast.makeText(this, "Długość geograficzna musi być w zakresie -180 do 180!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val geoUri = Uri.parse("geo:$latitude,$longitude?q=$latitude,$longitude")
            val mapIntent = Intent(Intent.ACTION_VIEW, geoUri)
            mapIntent.setPackage("com.google.android.apps.maps")
            startActivity(mapIntent)
        }


        // Aparat
        btnCamera.setOnClickListener {
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CAMERA_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val photo = data?.extras?.get("data") as Bitmap
            photoBitmap = photo
            imageView.setImageBitmap(photo)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putParcelable("photoBitmap", photoBitmap)
    }
}
