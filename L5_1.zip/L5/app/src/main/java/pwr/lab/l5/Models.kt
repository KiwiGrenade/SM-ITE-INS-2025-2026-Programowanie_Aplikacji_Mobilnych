package pwr.lab.l5

data class DaneKierunku(
    val id: Int,
    val nazwa: String,
    val opisKierunku: String,
    val iloscMiejsc: Int
)
