package pwr.lab.l5

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

class KierunkiViewModel : ViewModel() {
    private val _lista = mutableStateListOf<DaneKierunku>()
    val lista get() = _lista
    var query by mutableStateOf("")
    var sortByName by mutableStateOf(true)
    private var nextId = 1

    init {
        dodaj("Informatyka Techniczna", "WIT II stopnia", 120)
        dodaj("Automatyka i Robotyka", "WIT II stopnia", 90)
        dodaj("Teleinformatyka", "WIT II stopnia", 80)
    }

    fun widok(): List<DaneKierunku> {
        val base = if (query.isBlank()) _lista else _lista.filter {
            it.nazwa.contains(query, true) || it.opisKierunku.contains(query, true)
        }
        return if (sortByName) base.sortedBy { it.nazwa.lowercase() } else base.sortedBy { it.id }
    }

    fun dodaj(nazwa: String, opis: String, miejsca: Int) {
        _lista.add(DaneKierunku(nextId++, nazwa, opis, miejsca))
    }

    fun usun(id: Int) {
        _lista.removeAll { it.id == id }
    }

    fun aktualizuj(id: Int, nazwa: String, opis: String, miejsca: Int) {
        val i = _lista.indexOfFirst { it.id == id }
        if (i >= 0) _lista[i] = _lista[i].copy(nazwa = nazwa, opisKierunku = opis, iloscMiejsc = miejsca)
    }
}
