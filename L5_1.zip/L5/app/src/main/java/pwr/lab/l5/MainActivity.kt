package pwr.lab.l5

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val vm: KierunkiViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                App(vm)
            }
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: KierunkiViewModel) {
    var nazwa by remember { mutableStateOf("") }
    var opis by remember { mutableStateOf("") }
    var miejscaText by remember { mutableStateOf("") }
    var editId by remember { mutableStateOf<Int?>(null) }

    var nazwaError by remember { mutableStateOf(false) }
    var miejscaError by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Kierunki WIT II stopnia") }) }
    ) { p ->
        Column(
            Modifier
                .padding(p)
                .fillMaxSize()
                .imePadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = vm.query,
                    onValueChange = { vm.query = it },
                    label = { Text("Szukaj") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AssistChip(onClick = { vm.sortByName = true }, label = { Text("Sortuj: nazwa") })
                    AssistChip(onClick = { vm.sortByName = false }, label = { Text("Sortuj: id") })
                }

                OutlinedTextField(
                    value = nazwa,
                    onValueChange = {
                        nazwa = it
                        nazwaError = false
                    },
                    label = { Text("Nazwa kierunku") },
                    isError = nazwaError,
                    supportingText = {
                        if (nazwaError) Text("Pole 'Nazwa kierunku' nie może być puste")
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = opis,
                    onValueChange = { opis = it },
                    label = { Text("Opis") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = miejscaText,
                    onValueChange = {
                        miejscaText = it
                        miejscaError = false
                    },
                    label = { Text("Ilość miejsc") },
                    isError = miejscaError,
                    supportingText = {
                        if (miejscaError) Text("Wprowadź poprawną liczbę (bez liter)")
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = {
                        val m = miejscaText.toIntOrNull()
                        val validName = nazwa.isNotBlank()

                        if (!validName) {
                            nazwaError = true
                        }
                        if (m == null) {
                            miejscaError = true
                        }

                        if (validName && m != null) {
                            if (editId == null) {
                                vm.dodaj(nazwa.trim(), opis.trim(), m)
                            } else {
                                vm.aktualizuj(editId!!, nazwa.trim(), opis.trim(), m)
                                editId = null
                            }
                            nazwa = ""
                            opis = ""
                            miejscaText = ""
                        }
                    }) {
                        Text(if (editId == null) "Dodaj" else "Zapisz")
                    }

                    if (editId != null) {
                        OutlinedButton(onClick = {
                            editId = null
                            nazwa = ""
                            opis = ""
                            miejscaText = ""
                            nazwaError = false
                            miejscaError = false
                        }) { Text("Anuluj") }
                    }
                }
            }

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .weight(2f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                items(vm.widok(), key = { it.id }) { k ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(
                            Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("${k.id}. ${k.nazwa}", style = MaterialTheme.typography.titleMedium)
                            Text(k.opisKierunku)
                            Text("Miejsca: ${k.iloscMiejsc}")
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                OutlinedButton(onClick = {
                                    editId = k.id
                                    nazwa = k.nazwa
                                    opis = k.opisKierunku
                                    miejscaText = k.iloscMiejsc.toString()
                                }) { Text("Edytuj") }
                                OutlinedButton(onClick = { vm.usun(k.id) }) { Text("Usuń") }
                            }
                        }
                    }
                }
            }
        }
    }
}

