package pwr.lab.a4_1

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class BatteryBroadcastReceiver(private val onUpdate: (String, String) -> Unit) : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        intent ?: return
        val action = intent.action
        when (action) {
            Intent.ACTION_BATTERY_LOW -> {
                onUpdate("BATTERY_LOW", "Not plugged")
                Toast.makeText(context, "BATTERY LOW", Toast.LENGTH_SHORT).show()
            }
            Intent.ACTION_BATTERY_OKAY -> {
                onUpdate("BATTERY_OKAY", "—")
                Toast.makeText(context, "BATTERY OKAY", Toast.LENGTH_SHORT).show()
            }
            Intent.ACTION_POWER_CONNECTED -> {
                onUpdate("POWER_CONNECTED", "Connected")
                Toast.makeText(context, "POWER CONNECTED", Toast.LENGTH_SHORT).show()
            }
            Intent.ACTION_POWER_DISCONNECTED -> {
                onUpdate("POWER_DISCONNECTED", "Disconnected")
                Toast.makeText(context, "POWER DISCONNECTED", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
