package pwr.lab.a4_1

import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvPower: TextView
    private lateinit var btnCheckNow: Button

    private val receiver = BatteryBroadcastReceiver { statusText, powerText ->
        runOnUiThread {
            tvStatus.text = "Status: $statusText"
            tvPower.text = "Power: $powerText"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tv_status)
        tvPower = findViewById(R.id.tv_power)
        btnCheckNow = findViewById(R.id.btn_check_now)

        btnCheckNow.setOnClickListener {
            val batteryIntent: Intent? = registerReceiver(null, IntentFilter("android.intent.action.BATTERY_CHANGED"))
            batteryIntent?.let {
                val level = it.getIntExtra("level", -1)
                val scale = it.getIntExtra("scale", -1)
                val status = it.getIntExtra("status", -1)
                val plugged = it.getIntExtra("plugged", -1)

                val batteryPct = if(level>=0 && scale>0) (level * 100 / scale) else -1
                val statusText = when (status) {
                    2 -> "CHARGING"
                    3 -> "DISCHARGING"
                    4 -> "NOT_CHARGING"
                    5 -> "FULL"
                    else -> "UNKNOWN"
                }
                val powerText = when (plugged) {
                    1 -> "AC"
                    2 -> "USB"
                    4 -> "WIRELESS"
                    0 -> "Not plugged"
                    else -> "Unknown"
                }
                tvStatus.text = "Status: $statusText ($batteryPct%)"
                tvPower.text = "Power: $powerText"
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_LOW)
            addAction(Intent.ACTION_BATTERY_OKAY)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        registerReceiver(receiver, filter)
    }

    override fun onPause() {
        super.onPause()
        try {
            unregisterReceiver(receiver)
        } catch (ex: IllegalArgumentException) {
        }
    }
}
