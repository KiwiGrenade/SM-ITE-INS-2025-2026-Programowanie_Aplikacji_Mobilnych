package pwr.lab.l5

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class KierunkiViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.getInstance(application).kierunekDao()

    private val _lista = mutableStateListOf<DaneKierunku>()
    val lista get() = _lista

    var query by mutableStateOf("")
    var sortByName by mutableStateOf(true)

    init {
        odswiez()
    }

    private fun odswiez() {
        viewModelScope.launch {
            val fromDb = dao.getAll()
            _lista.clear()
            _lista.addAll(fromDb)
        }
    }

    fun widok(): List<DaneKierunku> {
        val base = if (query.isBlank()) _lista else _lista.filter {
            it.nazwa.contains(query, true) || it.opisKierunku.contains(query, true)
        }
        return if (sortByName) base.sortedBy { it.nazwa.lowercase() } else base.sortedBy { it.id }
    }

    fun dodaj(nazwa: String, opis: String, miejsca: Int) {
        viewModelScope.launch {
            val nowy = DaneKierunku(
                nazwa = nazwa,
                opisKierunku = opis,
                iloscMiejsc = miejsca,
                id = 0
            )
            dao.insert(nowy)
            odswiez()
        }
    }

    fun usun(id: Int) {
        viewModelScope.launch {
            val istniejący = _lista.firstOrNull { it.id == id } ?: return@launch
            dao.delete(istniejący)
            odswiez()
        }
    }

    fun aktualizuj(id: Int, nazwa: String, opis: String, miejsca: Int) {
        viewModelScope.launch {
            val istniejący = _lista.firstOrNull { it.id == id } ?: return@launch
            val zaktualizowany = istniejący.copy(
                nazwa = nazwa,
                opisKierunku = opis,
                iloscMiejsc = miejsca
            )
            dao.update(zaktualizowany)
            odswiez()
        }
    }
}
