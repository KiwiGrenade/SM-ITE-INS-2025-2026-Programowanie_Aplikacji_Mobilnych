package pwr.lab.l5

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface KierunekDao {
    @Query("SELECT * FROM kierunki ORDER BY id")
    suspend fun getAll(): List<DaneKierunku>

    @Insert
    suspend fun insert(kierunek: DaneKierunku)

    @Update
    suspend fun update(kierunek: DaneKierunku)

    @Delete
    suspend fun delete(kierunek: DaneKierunku)
}
