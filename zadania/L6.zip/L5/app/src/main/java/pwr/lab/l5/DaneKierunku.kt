package pwr.lab.l5

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "kierunki")
data class DaneKierunku(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nazwa: String,
    val opisKierunku: String,
    val iloscMiejsc: Int
)
