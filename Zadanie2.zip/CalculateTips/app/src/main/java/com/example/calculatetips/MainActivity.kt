package com.example.calculatetips

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener

class MainActivity : AppCompatActivity() {

    @SuppressLint("DefaultLocale")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editTextKosztPosilku = findViewById<EditText>(R.id.costEditText)
        val seekBarOcenaObslugi = findViewById<SeekBar>(R.id.serviceSeekBar)
        val textViewOcenaObslugi = findViewById<TextView>(R.id.serviceText)
        val radioGroupJedzenie = findViewById<RadioGroup>(R.id.foodRadioGroup)
        val textViewWynik = findViewById<TextView>(R.id.resultTextView)

        fun obliczNapiwek() {
            val tekstKosztu = editTextKosztPosilku.text.toString()
            if (tekstKosztu.isEmpty()) {
                textViewWynik.text = ""
                return
            }

            val koszt = tekstKosztu.toDouble()
            val ocenaObslugi = seekBarOcenaObslugi.progress
            val wybranyRadioId = radioGroupJedzenie.checkedRadioButtonId

            var procentNapiwku = 5.0

            // Modyfikacja napiwku w zależności od oceny obsługi
            if (ocenaObslugi > 8) procentNapiwku += 2.0
            if (ocenaObslugi < 4) procentNapiwku -= 2.0

            // Modyfikacja napiwku w zależności od jakości jedzenia
            when (wybranyRadioId) {
                R.id.radioYes -> procentNapiwku += 1.0
                R.id.radioNo -> procentNapiwku -= 1.0
                else -> {}
            }

            if (procentNapiwku < 0) procentNapiwku = 0.0

            val wartoscNapiwku = koszt * procentNapiwku / 100
            val calkowitaKwota = koszt + wartoscNapiwku

            textViewWynik.text = String.format(
                "Napiwek: %.2f zł (%.1f%%)\nDo zapłaty: %.2f zł",
                wartoscNapiwku, procentNapiwku, calkowitaKwota
            )
        }

        seekBarOcenaObslugi.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                textViewOcenaObslugi.text = "Ocena obsługi kelnerskiej: $progress / 10"
                obliczNapiwek()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        radioGroupJedzenie.setOnCheckedChangeListener { _, _ ->
            obliczNapiwek()
        }

        editTextKosztPosilku.addTextChangedListener {
            obliczNapiwek()
        }
    }
}
