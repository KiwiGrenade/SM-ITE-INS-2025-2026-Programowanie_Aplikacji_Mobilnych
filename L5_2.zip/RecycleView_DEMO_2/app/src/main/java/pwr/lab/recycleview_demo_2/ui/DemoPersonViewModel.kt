package pwr.lab.recycleview_demo_2.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import pwr.lab.recycleview_demo_2.model.Person

class DemoPersonViewModel : ViewModel() {

    // JJ prywatne źródło danych (MutableLiveData) przechowujące listę osób
    private val _personList = MutableLiveData<MutableList<Person>>(mutableListOf())

    // JJ publiczne, tylko do odczytu LiveData dla obserwatorów (np. UI)
    val personList: LiveData<MutableList<Person>> = _personList

    // JJ ustawia początkową zawartość listy osób
    fun init(persons: List<Person>) {
        _personList.value = persons.toMutableList()
    }

    // JJ dodaje nową osobę do listy i aktualizuje obserwatorów LiveData
    fun addPerson(person: Person) {
        val updatedList = _personList.value ?: mutableListOf()
        updatedList.add(person)
        _personList.value = updatedList
    }

    // JJ aktualizuje dane osoby na danej pozycji w liście i aktualizuje obserwatorów LiveData
    fun updatePerson(position: Int, updatedPerson: Person) {
        val updatedList = _personList.value ?: mutableListOf()
        updatedList[position] = updatedPerson
        _personList.value = updatedList
    }

    // JJ usuwa osobę z listy na wskazanej pozycji i aktualizuje obserwatorów LiveData
    fun removePerson(position: Int) {
        val updatedList = _personList.value ?: mutableListOf()
        updatedList.removeAt(position)
        _personList.value = updatedList
    }
}
