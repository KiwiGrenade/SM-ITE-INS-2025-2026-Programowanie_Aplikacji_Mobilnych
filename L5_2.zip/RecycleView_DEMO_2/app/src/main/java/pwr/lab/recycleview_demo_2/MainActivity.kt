package pwr.lab.recycleview_demo_2

import android.os.Bundle
import android.widget.EditText
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

import pwr.lab.recycleview_demo_2.model.Person
import pwr.lab.recycleview_demo_2.ui.DemoPersonAdapter
import pwr.lab.recycleview_demo_2.ui.DemoPersonViewModel


class MainActivity : AppCompatActivity() {
    private val personViewModel: DemoPersonViewModel by viewModels()
    private lateinit var personAdapter: DemoPersonAdapter

    // JJ początkowa lista osób (demo)
    private val demoInitialPersons = listOf(
        Person("Krzysztof", "Kowalski", 10),
        Person("Norbert", "Nowak", 18),
        Person("Maria", "Skłodowska-Curie", 50)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // JJ Zobacz ile osób jest na liście. Jeżeli 0, wypełnij listą demo
        val listSize = personViewModel.personList.value?.size ?: 0
        if(  listSize == 0  )
            personViewModel.init(demoInitialPersons)

        // JJ Inicjalizacja RecyclerView
        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // JJ Ustawienie adaptera z odrębnymi działaniami dla onShortClick oraz onLongClick
        personAdapter = DemoPersonAdapter(mutableListOf(),
            { position ->
            showAddOrEditPersonDialog(position)
        },
            { position ->
            showDeleteConfirmationDialog(position)
        })

        recyclerView.adapter = personAdapter

        // JJ Ustawienie obserwera na personList, który pozwala adapterowi na updatowanie listy
        personViewModel.personList.observe(this, Observer { updatedList ->
            personAdapter.updateList(updatedList)
        })

        // JJ Inicjalizacja przycisku FAB
        val fab: FloatingActionButton = findViewById(R.id.fab)
        fab.setOnClickListener {
            // JJ otwarcie dialogu dla dodania nowej osoby
            showAddOrEditPersonDialog(-1)
        }
    }

    // JJ Funkcja do wyświetlenia dialogu dodawania lub edytowania osoby
    private fun showAddOrEditPersonDialog(position: Int) {
        val person: Person? = if (position != -1) personViewModel.personList.value?.get(position) else null

        // JJ tworzymy widok dla dialogu
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_person, null)
        val editFirstName: EditText = dialogView.findViewById(R.id.editFirstName)
        val editLastName: EditText = dialogView.findViewById(R.id.editLastName)
        val editAge: EditText = dialogView.findViewById(R.id.editAge)

        // JJ jeśli edytujemy, wypełniamy dane osobowe
        person?.let {
            editFirstName.setText(it.firstName)
            editLastName.setText(it.lastName)
            editAge.setText(it.age.toString())
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (person == null) "Dodaj nową osobę" else "Edytuj osobę")
            .setView(dialogView)
            .setPositiveButton("Zapisz") { _, _ ->
                // JJ Pobieramy dane z formularza
                val firstName = editFirstName.text.toString()
                val lastName = editLastName.text.toString()
                val age = editAge.text.toString().toIntOrNull() ?: 0

                if (firstName.isNotBlank() && lastName.isNotBlank() && age > 0) {
                    if (person == null) {
                        // JJ dodaj nową osobę do listy
                        val newPerson = Person(firstName, lastName, age)
                        personViewModel.addPerson(newPerson)  //uwaga: wcześniej były tu dwie operacje
                        // JJ ponieważ mamy dodany obserwer na personViewModel, to nie musimy powiadamiać adaptera o zmianie
                    } else {
                        // JJ zaktualizuj dane osoby
                        val updatedPerson = Person(firstName, lastName, age)
                        // JJ ponieważ mamy dodany obserwer na personViewModel, to nie musimy powiadamiać adaptera o zmianie
                        personViewModel.updatePerson(position, updatedPerson)  //uwaga: wcześniej były tu dwie operacje
                    }
                }
            }
            .setNegativeButton("Anuluj", null)
            .create()

        dialog.show()
    }


    // JJ funkcja wyświetlająca dialog upewniający się o usuwaniu obiektu
    private fun showDeleteConfirmationDialog(position: Int) {
        val person = personViewModel.personList.value?.get(position)

        // JJ tworzenie dialogu
        val dialog = AlertDialog.Builder(this)
            .setTitle("Czy na pewno chcesz usunąć?")
            .setMessage("Czy na pewno chcesz usunąć osobę: ${person?.firstName} ${person?.lastName}?")
            .setPositiveButton("Tak") { _, _ ->
                // JJ jeżeli klikniemy "Tak", personViewModel usuwa osobę
                personViewModel.removePerson(position)
            }
            .setNegativeButton("Anuluj", null) // JJ w przeciwnym wypadku nic nie robimy
            .create()

        dialog.show()
    }

}
