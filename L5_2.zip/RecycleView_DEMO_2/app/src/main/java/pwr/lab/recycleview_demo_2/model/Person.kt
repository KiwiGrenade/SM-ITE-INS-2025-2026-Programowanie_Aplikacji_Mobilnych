package pwr.lab.recycleview_demo_2.model

// JJ oddelegowanie klasy Person do osobnego pliku
data class Person(
    val firstName: String,
    val lastName: String,
    val age: Int
)
