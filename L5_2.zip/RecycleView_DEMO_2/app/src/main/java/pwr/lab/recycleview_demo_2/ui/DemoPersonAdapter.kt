package pwr.lab.recycleview_demo_2.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import pwr.lab.recycleview_demo_2.R
import pwr.lab.recycleview_demo_2.model.Person

class DemoPersonAdapter(
    private var personList: List<Person>,
    private val onShortClick: (Int) -> Unit, // JJ callback dla long-click
    private val onLongClick: (Int) -> Unit // JJ callback dla short-click
) : RecyclerView.Adapter<DemoPersonAdapter.PersonViewHolder>() {

    class PersonViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView: TextView = itemView.findViewById(R.id.textName)
        val ageTextView: TextView = itemView.findViewById(R.id.textAge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PersonViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.demo_item_person, parent, false)
        return PersonViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: PersonViewHolder, position: Int) {
        val person = personList[position]
        holder.nameTextView.text = "${person.firstName} ${person.lastName}"
        holder.ageTextView.text = "Wiek: ${person.age}"

        // JJ dodanie obsługi onShortClick
        holder.itemView.setOnClickListener {
            onShortClick(position)
        }

        // JJ dodanie obsługi onLongClick
        holder.itemView.setOnLongClickListener {
            onLongClick(position)
            true
        }

    }

    // JJ funkcja zwracająca wielkość osób w liście
    override fun getItemCount() = personList.size

    // JJ funkcja służąca do updatowania listy (wykorzystywana przez observer w DemoPersonViewModel)
    fun updateList(updatedList: List<Person>) {
        personList = updatedList.toMutableList()
        notifyDataSetChanged()
    }

}
